var searchData=
[
  ['mail_20queue_20management',['Mail Queue Management',['../group___c_m_s_i_s___r_t_o_s___mail.html',1,'']]],
  ['message_20queue_20management',['Message Queue Management',['../group___c_m_s_i_s___r_t_o_s___message.html',1,'']]],
  ['mutex_20management',['Mutex Management',['../group___c_m_s_i_s___r_t_o_s___mutex_mgmt.html',1,'']]],
  ['memory_20pool_20management',['Memory Pool Management',['../group___c_m_s_i_s___r_t_o_s___pool_mgmt.html',1,'']]]
];
